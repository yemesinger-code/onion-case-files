import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Header from "./components/Header";
import Footer from "./components/Footer";
import MobileStickyCTA from "./components/MobileStickyCTA";
import Home from "./pages/Home";
import About from "./pages/About";
import Cases from "./pages/Cases";
import Parents from "./pages/Parents";
import Shop from "./pages/Shop";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import Accessibility from "./pages/Accessibility";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Refunds from "./pages/Refunds";
import { I18nextProvider } from 'react-i18next';
import i18n from './lib/i18n';
import { useEffect } from 'react';

function Router() {
  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    i18n.changeLanguage(savedLanguage);
    document.documentElement.dir = savedLanguage === 'he' ? 'rtl' : 'ltr';
    document.documentElement.lang = savedLanguage;
  }, []);

  // make sure to consider if you need authentication for certain routes
  return (
    <div className="flex flex-col min-h-screen">
      {/* Skip to Main Content Link */}
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-0 focus:left-0 focus:z-50 focus:bg-primary focus:text-white focus:p-2 focus:font-bold">
        Skip to Main Content
      </a>
      <Header />
      <main id="main-content" className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/cases" component={Cases} />
          <Route path="/parents" component={Parents} />
          <Route path="/shop" component={Shop} />
          <Route path="/contact" component={Contact} />
          <Route path="/thank-you" component={ThankYou} />
          <Route path="/accessibility" component={Accessibility} />
          <Route path="/terms" component={Terms} />
          <Route path="/privacy" component={Privacy} />
          <Route path="/refunds" component={Refunds} />
          <Route path="/404" component={NotFound} />
          {/* Final fallback route */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <MobileStickyCTA />
      <Footer />
    </div>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <I18nextProvider i18n={i18n}>
        <ThemeProvider
          defaultTheme="light"
          // switchable
        >
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </I18nextProvider>
    </ErrorBoundary>
  );
}

export default App;
