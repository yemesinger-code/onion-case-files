import { useState, useRef } from 'react';
import { Upload, X } from 'lucide-react';

interface UploadedFile {
  id: string;
  name: string;
  preview: string;
  isStamped: boolean;
}

export default function EvidenceUpload() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragActive(true);
    } else if (e.type === 'dragleave') {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const files = e.dataTransfer.files;
    processFiles(files);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const processFiles = (files: FileList) => {
    Array.from(files).forEach(file => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const newFile: UploadedFile = {
            id: Math.random().toString(36).substring(7),
            name: file.name,
            preview: e.target?.result as string,
            isStamped: false,
          };
          setUploadedFiles(prev => [...prev, newFile]);

          // Trigger stamp animation after a short delay
          setTimeout(() => {
            setUploadedFiles(prev =>
              prev.map(f => f.id === newFile.id ? { ...f, isStamped: true } : f)
            );
          }, 100);
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const removeFile = (id: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Upload Zone */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`border-4 border-dashed rounded-lg p-8 text-center transition-all cursor-pointer ${
          isDragActive
            ? 'border-green-600 bg-green-50 border-solid'
            : 'border-amber-900 bg-yellow-50 hover:border-amber-700'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          onChange={handleFileInput}
          className="hidden"
        />

        <div
          onClick={() => fileInputRef.current?.click()}
          className="cursor-pointer"
        >
          <div className="text-4xl mb-3">📁</div>
          <h3 className="text-lg font-typewriter font-bold text-amber-900 mb-2">
            CASE FILE FOLDER
          </h3>
          <p className="text-amber-800 font-mono text-sm mb-3">
            Drag & drop your experiment photos here
          </p>
          <p className="text-amber-700 font-mono text-xs">
            or click to browse
          </p>
        </div>

        {isDragActive && (
          <div className="mt-4 text-green-700 font-mono text-sm">
            ✓ Drop files to submit evidence
          </div>
        )}
      </div>

      {/* Safety Disclaimer */}
      <div className="bg-red-50 border-2 border-red-900 border-dashed p-4 rounded">
        <p className="text-red-900 font-mono text-xs">
          🔐 <strong>SAFETY PROTOCOL:</strong> All evidence is reviewed by HQ before being declassified (published).
        </p>
      </div>

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-typewriter font-bold text-amber-900">SUBMITTED EVIDENCE ({uploadedFiles.length})</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {uploadedFiles.map(file => (
              <div
                key={file.id}
                className="relative border-2 border-amber-900 rounded-lg overflow-hidden bg-yellow-50 group"
              >
                {/* Image Preview */}
                <img
                  src={file.preview}
                  alt={file.name}
                  className="w-full h-48 object-cover"
                />

                {/* Stamp Animation */}
                {file.isStamped && (
                  <div
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                    style={{
                      animation: 'stampSlam 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards',
                    }}
                  >
                    <div
                      className="text-3xl font-bold text-red-600 opacity-60 transform -rotate-45"
                      style={{
                        textShadow: '2px 2px 4px rgba(0,0,0,0.3)',
                        fontWeight: 'bold',
                        letterSpacing: '2px',
                      }}
                    >
                      RECEIVED
                    </div>
                  </div>
                )}

                {/* File Info & Delete */}
                <div className="p-3 bg-yellow-100 border-t-2 border-amber-900 flex justify-between items-center">
                  <div className="flex-1 min-w-0">
                    <p className="text-amber-900 font-mono text-xs truncate">
                      {file.name}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFile(file.id)}
                    className="ml-2 text-red-600 hover:text-red-800 transition"
                    title="Remove file"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Submit Button */}
          <button className="w-full bg-amber-900 hover:bg-amber-950 text-yellow-50 font-typewriter font-bold py-3 rounded transition flex items-center justify-center gap-2">
            <Upload size={20} />
            SUBMIT EVIDENCE TO HQ
          </button>
        </div>
      )}

      {/* Animation Styles */}
      <style>{`
        @keyframes stampSlam {
          0% {
            transform: rotate(-45deg) scale(0) translateY(-100px);
            opacity: 0;
          }
          50% {
            opacity: 0.8;
          }
          100% {
            transform: rotate(-45deg) scale(1) translateY(0);
            opacity: 0.6;
          }
        }
      `}</style>
    </div>
  );
}
