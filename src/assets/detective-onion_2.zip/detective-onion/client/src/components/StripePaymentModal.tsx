import { useState } from 'react';
import { X } from 'lucide-react';

interface StripePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
}

export default function StripePaymentModal({ isOpen, onClose, amount }: StripePaymentModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiry: '',
    cvc: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAuthorize = async () => {
    setIsProcessing(true);
    // Simulate 2-second processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setIsSuccess(true);
  };

  const handleClose = () => {
    setFormData({ cardNumber: '', expiry: '', cvc: '' });
    setIsProcessing(false);
    setIsSuccess(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {/* Success Screen */}
      {isSuccess ? (
        <div className="bg-yellow-50 border-4 border-amber-900 rounded-lg p-8 max-w-md w-full relative overflow-hidden">
          {/* Stamp effect */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div
              className="text-6xl font-bold text-red-500 opacity-20 transform -rotate-45 animate-bounce"
              style={{
                textShadow: '2px 2px 4px rgba(0,0,0,0.3)',
                animation: 'stampSlam 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
              }}
            >
              ✓ APPROVED
            </div>
          </div>

          <div className="relative z-10 text-center">
            <div className="text-4xl mb-4">🎉</div>
            <h2 className="text-2xl font-typewriter font-bold text-amber-900 mb-2">MISSION FUNDED</h2>
            <p className="text-amber-800 font-mono text-sm mb-4">
              Transaction ID: {Math.random().toString(36).substring(7).toUpperCase()}
            </p>
            <div className="bg-white border-2 border-dashed border-amber-900 p-4 mb-6 rounded">
              <p className="text-amber-900 font-mono text-sm">
                Amount Authorized: <strong>${amount.toFixed(2)}</strong>
              </p>
              <p className="text-amber-900 font-mono text-xs mt-2">
                Status: ENCRYPTED TRANSMISSION COMPLETE
              </p>
            </div>
            <p className="text-amber-800 text-sm mb-6">
              Your Detective Kit will be dispatched within 24 hours. Check your email for tracking details.
            </p>
            <button
              onClick={handleClose}
              className="bg-amber-900 hover:bg-amber-950 text-yellow-50 px-6 py-2 rounded font-typewriter font-bold transition"
            >
              Return to Headquarters
            </button>
          </div>

          <style>{`
            @keyframes stampSlam {
              0% {
                transform: rotate(-45deg) scale(0.5) translateY(-100px);
                opacity: 0;
              }
              50% {
                opacity: 0.3;
              }
              100% {
                transform: rotate(-45deg) scale(1) translateY(0);
                opacity: 0.2;
              }
            }
          `}</style>
        </div>
      ) : (
        /* Payment Form */
        <div className="bg-gray-100 border-4 border-gray-800 rounded-lg p-8 max-w-md w-full">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-typewriter font-bold text-gray-800">SECURE TRANSACTION TERMINAL</h2>
            <button
              onClick={handleClose}
              disabled={isProcessing}
              className="text-gray-600 hover:text-gray-900 disabled:opacity-50"
            >
              <X size={24} />
            </button>
          </div>

          <div className="bg-gray-200 border-2 border-gray-400 p-4 mb-6 rounded">
            <p className="text-gray-700 font-mono text-sm mb-2">Amount to Authorize:</p>
            <p className="text-2xl font-bold text-gray-900 font-mono">${amount.toFixed(2)}</p>
          </div>

          {/* Card Input Fields */}
          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-gray-700 font-mono text-sm mb-2">Card Number</label>
              <input
                type="text"
                name="cardNumber"
                placeholder="4111 1111 1111 1111"
                value={formData.cardNumber}
                onChange={handleInputChange}
                disabled={isProcessing}
                maxLength={19}
                className="w-full px-3 py-2 bg-white border-2 border-gray-400 rounded font-mono text-sm disabled:opacity-50"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 font-mono text-sm mb-2">Expiry (MM/YY)</label>
                <input
                  type="text"
                  name="expiry"
                  placeholder="12/25"
                  value={formData.expiry}
                  onChange={handleInputChange}
                  disabled={isProcessing}
                  maxLength={5}
                  className="w-full px-3 py-2 bg-white border-2 border-gray-400 rounded font-mono text-sm disabled:opacity-50"
                />
              </div>
              <div>
                <label className="block text-gray-700 font-mono text-sm mb-2">CVC</label>
                <input
                  type="text"
                  name="cvc"
                  placeholder="123"
                  value={formData.cvc}
                  onChange={handleInputChange}
                  disabled={isProcessing}
                  maxLength={3}
                  className="w-full px-3 py-2 bg-white border-2 border-gray-400 rounded font-mono text-sm disabled:opacity-50"
                />
              </div>
            </div>
          </div>

          {/* Security Message */}
          <div className="bg-yellow-50 border-2 border-yellow-800 p-3 mb-6 rounded">
            <p className="text-yellow-900 font-mono text-xs">
              🔒 <strong>Encrypted Transmission via SSL Channel</strong>
            </p>
            <p className="text-yellow-800 font-mono text-xs mt-1">
              Your payment information is secure and encrypted.
            </p>
          </div>

          {/* Processing State */}
          {isProcessing && (
            <div className="bg-gray-300 border-2 border-gray-600 p-4 mb-4 rounded text-center">
              <div className="inline-block animate-spin mb-2">⚙️</div>
              <p className="text-gray-800 font-mono text-sm">Encrypting Transmission...</p>
            </div>
          )}

          {/* Authorize Button */}
          <button
            onClick={handleAuthorize}
            disabled={isProcessing}
            className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-typewriter font-bold py-3 rounded transition mb-3"
          >
            {isProcessing ? 'PROCESSING...' : 'AUTHORIZE FUNDING'}
          </button>

          <p className="text-gray-600 font-mono text-xs text-center">
            By clicking above, you authorize this transaction.
          </p>
        </div>
      )}
    </div>
  );
}
