import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

export default function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const isHebrew = i18n.language === 'he';

  const switchLanguage = (lang: string) => {
    if (i18n.language !== lang) {
      i18n.changeLanguage(lang);
      localStorage.setItem('language', lang);
      document.documentElement.dir = lang === 'he' ? 'rtl' : 'ltr';
      document.documentElement.lang = lang;
    }
  };

  return (
    <div className="flex gap-1 border border-border rounded-lg p-1 bg-background">
      {/* English Button */}
      <Button
        onClick={() => switchLanguage('en')}
        variant={!isHebrew ? 'default' : 'ghost'}
        size="sm"
        className={`focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary flex items-center gap-1 transition-all ${
          !isHebrew ? 'bg-primary text-primary-foreground shadow-md' : 'text-foreground hover:bg-muted'
        }`}
        title="Switch to English"
      >
        🇺🇸 English
        {!isHebrew && <Check size={16} />}
      </Button>

      {/* Hebrew Button */}
      <Button
        onClick={() => switchLanguage('he')}
        variant={isHebrew ? 'default' : 'ghost'}
        size="sm"
        className={`focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary flex items-center gap-1 transition-all ${
          isHebrew ? 'bg-primary text-primary-foreground shadow-md' : 'text-foreground hover:bg-muted'
        }`}
        title="Switch to Hebrew"
      >
        🇮🇱 עברית
        {isHebrew && <Check size={16} />}
      </Button>
    </div>
  );
}
