export default function ProductMockup() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <svg
        viewBox="0 0 300 350"
        className="w-full h-full max-w-sm"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Box Shadow */}
        <ellipse cx="150" cy="320" rx="100" ry="15" fill="rgba(0,0,0,0.1)" />

        {/* Main Box - Front */}
        <rect x="40" y="80" width="220" height="200" fill="#D4A574" stroke="#8B6F47" strokeWidth="2" />

        {/* Box Top Edge (3D effect) */}
        <polygon
          points="40,80 50,60 270,60 260,80"
          fill="#E8C4A0"
          stroke="#8B6F47"
          strokeWidth="2"
        />

        {/* Box Right Edge (3D effect) */}
        <polygon
          points="260,80 270,60 270,260 260,280"
          fill="#B8956A"
          stroke="#8B6F47"
          strokeWidth="2"
        />

        {/* Detective Badge - Top Left */}
        <circle cx="75" cy="120" r="18" fill="#DC2626" stroke="#991B1B" strokeWidth="2" />
        <text
          x="75"
          y="125"
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fill="white"
          fontFamily="Arial"
        >
          🔍
        </text>

        {/* Title - Center */}
        <text
          x="150"
          y="145"
          textAnchor="middle"
          fontSize="18"
          fontWeight="bold"
          fill="#2D1B00"
          fontFamily="'JetBrains Mono', monospace"
        >
          DETECTIVE
        </text>
        <text
          x="150"
          y="168"
          textAnchor="middle"
          fontSize="18"
          fontWeight="bold"
          fill="#2D1B00"
          fontFamily="'JetBrains Mono', monospace"
        >
          ONION
        </text>

        {/* Subtitle */}
        <text
          x="150"
          y="190"
          textAnchor="middle"
          fontSize="10"
          fill="#5C3D2E"
          fontFamily="Arial"
        >
          STARTER KIT
        </text>

        {/* Decorative Elements */}
        <circle cx="225" cy="130" r="8" fill="#F59E0B" opacity="0.7" />
        <rect x="60" y="210" width="180" height="2" fill="#8B6F47" opacity="0.5" />

        {/* Bottom Text */}
        <text
          x="150"
          y="250"
          textAnchor="middle"
          fontSize="9"
          fill="#5C3D2E"
          fontFamily="Arial"
        >
          Complete Investigation Set
        </text>
        <text
          x="150"
          y="265"
          textAnchor="middle"
          fontSize="8"
          fill="#8B6F47"
          fontFamily="Arial"
        >
          12 Premium Tools • Experiment Guide
        </text>

        {/* Seal/Badge - Bottom Right */}
        <circle cx="240" cy="250" r="12" fill="#DC2626" opacity="0.8" />
        <text
          x="240"
          y="255"
          textAnchor="middle"
          fontSize="8"
          fontWeight="bold"
          fill="white"
          fontFamily="Arial"
        >
          ✓
        </text>
      </svg>
    </div>
  );
}
