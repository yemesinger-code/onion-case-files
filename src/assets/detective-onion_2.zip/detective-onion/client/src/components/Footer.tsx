import { Mail, Facebook, Instagram, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <footer className="bg-card border-t-2 border-border mt-16">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="font-bold text-lg mb-4 typewriter-text">Detective Onion</h3>
            <p className="text-sm text-muted-foreground">
              Solving kitchen mysteries through science and curiosity. One experiment at a time.
            </p>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary rounded px-1">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms" className="text-muted-foreground hover:text-foreground transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary rounded px-1">
                  Terms of Use
                </a>
              </li>
              <li>
                <a href="/refunds" className="text-muted-foreground hover:text-foreground transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary rounded px-1">
                  Cancellation Policy
                </a>
              </li>
              <li>
                <a href="/accessibility" className="text-muted-foreground hover:text-foreground transition-colors">
                  Accessibility
                </a>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/cases" className="text-muted-foreground hover:text-foreground transition-colors">
                  Case Archive
                </a>
              </li>
              <li>
                <a href="/parents" className="text-muted-foreground hover:text-foreground transition-colors">
                  Parents Zone
                </a>
              </li>
              <li>
                <a href="/shop" className="text-muted-foreground hover:text-foreground transition-colors">
                  The Armory
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-semibold mb-4">Receive Encrypted Telegrams</h4>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <Input
                type="email"
                placeholder="Your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="text-sm focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
              />
              <Button
                type="submit"
                size="sm"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
              >
                {subscribed ? '✓ Subscribed' : 'Subscribe'}
              </Button>
            </form>
          </div>
        </div>

        {/* Social & Copyright */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row items-center justify-between">
          <p className="text-sm text-muted-foreground mb-4 md:mb-0">
            © 2024 Detective Onion Agency. All mysteries solved.
          </p>
          <div className="flex gap-4">
            <a
              href="#facebook"
              className="p-2 hover:bg-muted rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
              aria-label="Facebook"
            >
              <Facebook size={20} />
            </a>
            <a
              href="#instagram"
              className="p-2 hover:bg-muted rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
              aria-label="Instagram"
            >
              <Instagram size={20} />
            </a>
            <a
              href="#twitter"
              className="p-2 hover:bg-muted rounded-lg transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
              aria-label="Twitter"
            >
              <Twitter size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
