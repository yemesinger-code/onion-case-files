import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

export default function MobileStickyCTA() {
  const [isVisible, setIsVisible] = useState(false);
  const [location] = useLocation();

  // Hide on certain pages where it's not needed
  const hiddenPages = ['/shop', '/thank-you', '/404'];
  const shouldHide = hiddenPages.includes(location);

  useEffect(() => {
    // Show sticky CTA after scrolling 500px on mobile
    const handleScroll = () => {
      if (window.innerWidth < 768) {
        setIsVisible(window.scrollY > 500);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (shouldHide || !isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 md:hidden bg-accent text-accent-foreground p-3 shadow-lg z-50 flex gap-2">
      <Link href="/shop" className="flex-1">
        <a>
          <Button
            size="sm"
            className="w-full bg-accent-foreground text-accent hover:bg-accent-foreground/90 font-bold"
          >
            Get Kit Now
          </Button>
        </a>
      </Link>
      <button
        onClick={() => setIsVisible(false)}
        className="px-3 py-2 hover:bg-accent/80 rounded transition-colors"
        aria-label="Close"
      >
        <X size={20} />
      </button>
    </div>
  );
}
