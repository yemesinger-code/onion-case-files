import { useEffect } from 'react';
import { updateSEOMeta, seoConfig } from '@/lib/seo';

export default function Accessibility() {
  useEffect(() => {
    updateSEOMeta({
      title: 'Accessibility Statement - Detective Onion',
      description: 'Detective Onion is committed to WCAG 2.1 AA accessibility compliance. Learn about our accessibility features and how to report issues.',
    });
  }, []);

  return (
    <main className="min-h-screen bg-[#f4f1ea] font-sans text-stone-800">
      {/* Texture Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] mix-blend-multiply bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]"></div>

      <div className="container mx-auto px-4 py-12 max-w-3xl relative z-10">
        <h1 className="text-4xl font-bold font-typewriter mb-8 border-b-4 border-stone-800 pb-4">
          Accessibility Statement
        </h1>

        <div className="space-y-6 bg-white p-8 rounded-sm shadow-md border border-stone-200">
          <p className="text-lg">
            <strong>Detective Onion Agency</strong> is committed to providing a website that is accessible to the widest possible audience, regardless of circumstance and ability. We aim to adhere as closely as possible to the Web Content Accessibility Guidelines (WCAG 2.1, Level AA).
          </p>

          <h2 className="text-2xl font-bold font-typewriter mt-6">Actions Taken</h2>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Keyboard Navigation:</strong> The entire site can be navigated using the Tab key.</li>
            <li><strong>Screen Reader Compatibility:</strong> We use semantic HTML (main, nav, article) and ARIA labels.</li>
            <li><strong>Visuals:</strong> All mission-critical images and evidence files have descriptive Alt Text.</li>
            <li><strong>Focus Indicators:</strong> Interactive elements have clear visual outlines when focused.</li>
          </ul>

          <h2 className="text-2xl font-bold font-typewriter mt-6">Browser & Assistive Technology</h2>
          <p>
            Our site is designed to be compatible with the following assistive technologies:
            Chrome, Firefox, Safari, and Edge on Windows and Macintosh, with NVDA or VoiceOver.
          </p>

          <h2 className="text-2xl font-bold font-typewriter mt-6">Feedback & Issues</h2>
          <div className="bg-stone-100 p-4 border-l-4 border-stone-800">
            <p className="mb-2">
              Despite our very best efforts to allow anyone to adjust the website to their needs, there may still be pages or sections that are not fully accessible or are in the process of becoming so.
            </p>
            <p>
              If you have discovered a bug, found a barrier, or have trouble with any part of the site, please report it to our <strong>Accessibility Coordinator</strong>:
            </p>
            <ul className="mt-4 font-mono text-sm">
              <li><span role="img" aria-label="email">📧</span> Email: info@detectiveonion.com</li>
              <li><span role="img" aria-label="phone">📞</span> Phone/WhatsApp: +1 (555) 123-4567</li>
            </ul>
          </div>
          
          <p className="text-sm text-stone-500 mt-8">
            Statement updated on: {new Date().toLocaleDateString()}
          </p>
        </div>
      </div>
    </main>
  );
}
