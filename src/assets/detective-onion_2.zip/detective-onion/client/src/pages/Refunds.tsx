import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { updateSEOMeta, seoConfig } from '@/lib/seo';

export default function Refunds() {
  const { t } = useTranslation();

  useEffect(() => {
    updateSEOMeta(seoConfig.refunds || {
      title: 'Cancellation & Refund Policy | Detective Onion',
      description: 'Learn about our 30-day satisfaction guarantee and refund policy for Detective Onion kits.'
    });
  }, []);

  return (
    <main className="min-h-screen bg-[#f4f1ea] font-sans text-stone-800 py-12 px-4">
      {/* Texture Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] mix-blend-multiply bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]"></div>

      <div className="container mx-auto max-w-3xl bg-white p-8 rounded-sm shadow-md border border-stone-200 relative z-10">
        <h1 className="text-3xl md:text-4xl font-bold font-typewriter mb-6 border-b-4 border-stone-800 pb-4">
          {t('refunds.title')}
        </h1>
        
        <div className="space-y-6 text-sm md:text-base leading-relaxed">
          {/* Section 1 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              {t('refunds.section1_title')}
            </h2>
            <p>{t('refunds.section1_content')}</p>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              {t('refunds.section2_title')}
            </h2>
            <ul className="list-disc pl-5 space-y-2 text-stone-700">
              <li>{t('refunds.section2_item1')}</li>
              <li>{t('refunds.section2_item2')}</li>
            </ul>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              {t('refunds.section3_title')}
            </h2>
            <p>{t('refunds.section3_content')}</p>
          </section>
        </div>
      </div>
    </main>
  );
}
