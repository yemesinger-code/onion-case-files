import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mail, MessageSquare, Phone, Upload } from 'lucide-react';
import { triggerInteraction } from '@/lib/interactions';
import { updateSEOMeta, seoConfig } from '@/lib/seo';
import EvidenceUpload from '@/components/EvidenceUpload';

export default function Contact() {
  useEffect(() => {
    updateSEOMeta(seoConfig.contact);
  }, []);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setSubmitted(true);
    setTimeout(() => {
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold typewriter-text">Report a Mystery</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Found a new kitchen mystery? Have a question? Report it here.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 md:py-24">
        <div className="container max-w-4xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-start gap-4">
                  <Mail size={24} className="text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Email</h3>
                    <p className="text-sm text-muted-foreground">
                      <a href="mailto:info@detectiveonion.com" className="hover:text-foreground transition-colors">
                        info@detectiveonion.com
                      </a>
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-start gap-4">
                  <Phone size={24} className="text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">WhatsApp Business</h3>
                    <p className="text-sm text-muted-foreground">
                      <a href="https://wa.me/1234567890" className="hover:text-foreground transition-colors">
                        +1 (555) 123-4567
                      </a>
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-start gap-4">
                  <MessageSquare size={24} className="text-secondary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Response Time</h3>
                    <p className="text-sm text-muted-foreground">
                      We typically respond within 24 hours during business days
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-yellow-50 border-2 border-yellow-600 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow relative p-8">
                <div className="mb-6">
                  <span className="stamp confidential">INTELLIGENCE REPORT</span>
                </div>

                <h2 className="text-2xl font-bold mb-6 typewriter-text">Submit Your Report</h2>

                {submitted ? (
                  <div className="bg-green-50 border-2 border-green-600 rounded-lg p-6 text-center">
                    <div className="text-4xl mb-3">✓</div>
                    <h3 className="font-bold text-lg text-green-900 mb-2">Report Received!</h3>
                    <p className="text-green-800">
                      Thank you for your submission. Our detective team will review it shortly.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Name */}
                    <div>
                      <label className="block text-sm font-semibold mb-2 text-yellow-900">
                        Your Name *
                      </label>
                      <Input
                        type="text"
                        name="name"
                        placeholder="Detective's name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-white border-yellow-300"
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-sm font-semibold mb-2 text-yellow-900">
                        Email Address *
                      </label>
                      <Input
                        type="email"
                        name="email"
                        placeholder="your@email.com"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-white border-yellow-300"
                      />
                    </div>

                    {/* Phone */}
                    <div>
                      <label className="block text-sm font-semibold mb-2 text-yellow-900">
                        Phone Number
                      </label>
                      <Input
                        type="tel"
                        name="phone"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full bg-white border-yellow-300"
                      />
                    </div>

                    {/* Subject */}
                    <div>
                      <label className="block text-sm font-semibold mb-2 text-yellow-900">
                        Report Type *
                      </label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        required
                        className="w-full px-3 py-2 border-2 border-yellow-300 rounded-lg bg-white text-yellow-900 font-medium"
                      >
                        <option value="">Select a report type...</option>
                        <option value="new-mystery">New Kitchen Mystery</option>
                        <option value="experiment-variation">Experiment Variation</option>
                        <option value="question">Question</option>
                        <option value="feedback">Feedback</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    {/* Message */}
                    <div>
                      <label className="block text-sm font-semibold mb-2 text-yellow-900">
                        Your Report *
                      </label>
                      <textarea
                        name="message"
                        placeholder="Describe your mystery, question, or feedback..."
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        className="w-full px-3 py-2 border-2 border-yellow-300 rounded-lg bg-white text-yellow-900 font-medium resize-none"
                      />
                    </div>

                    {/* Evidence Upload */}
                    <div className="border-t-2 border-yellow-300 pt-6 mt-6">
                      <EvidenceUpload />
                    </div>

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      disabled={!formData.name || !formData.email || !formData.subject || !formData.message}
                      size="lg"
                      className="w-full bg-yellow-700 hover:bg-yellow-800 text-white font-bold button-typewriter"
                      onClick={() => triggerInteraction('stamp')}
                    >
                      Submit Report
                    </Button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-popover/30">
        <div className="container max-w-3xl">
          <h2 className="text-3xl font-bold mb-12 text-center typewriter-text">Common Questions</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h3 className="font-bold mb-2">How do I share my experiment photos?</h3>
              <p className="text-sm text-muted-foreground">
                Email your photos to experiments@detectiveonion.com with a description. We love seeing detectives in action!
              </p>
            </div>

            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h3 className="font-bold mb-2">How long does it take to get a response?</h3>
              <p className="text-sm text-muted-foreground">
                We aim to respond to all inquiries within 24 hours during business days. Popular mysteries may be featured on our site!
              </p>
            </div>

            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h3 className="font-bold mb-2">Can I suggest a new experiment?</h3>
              <p className="text-sm text-muted-foreground">
                Absolutely! We're always looking for new mysteries to solve. Send us your ideas through the contact form.
              </p>
            </div>

            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h3 className="font-bold mb-2">What if I found a safety issue?</h3>
              <p className="text-sm text-muted-foreground">
                Please contact us immediately at info@detectiveonion.com with details. Your safety is our top priority.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
