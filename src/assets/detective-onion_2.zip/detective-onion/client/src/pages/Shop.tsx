import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Check, Lock, Shield } from 'lucide-react';
import { useLocation } from 'wouter';
import { triggerInteraction } from '@/lib/interactions';
import ProductMockup from '@/components/ProductMockup';
import { updateSEOMeta, seoConfig } from '@/lib/seo';
import StripePaymentModal from '@/components/StripePaymentModal';

export default function Shop() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    updateSEOMeta(seoConfig.shop);
  }, []);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    cardNumber: '',
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  const kitContents = [
    'Detective Badge & ID Card',
    'Magnifying Glass (Premium)',
    'Investigation Notebook',
    'Secret Ink Kit (Lemon Juice)',
    'Baking Soda & Vinegar Set',
    'Food Coloring (5 Colors)',
    'Measuring Spoons & Cups',
    'Safety Goggles',
    'Rubber Gloves',
    'Experiment Guide (50 Cases)',
    'Access to Online Case Archive',
    'Exclusive Detective Community',
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triggerInteraction('stamp');
    setIsPaymentModalOpen(true);
  };

  const handlePaymentClose = () => {
    setIsPaymentModalOpen(false);
    setTimeout(() => {
      setLocation('/thank-you');
    }, 500);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-accent/10 to-transparent">
        <div className="container text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold typewriter-text">The Armory</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to become a certified Detective Onion investigator
          </p>
        </div>
      </section>

      {/* Product Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Product Image/Mockup */}
            <div className="space-y-6">
              <div className="aspect-square bg-gradient-to-br from-yellow-50 to-amber-100 border-2 border-yellow-600 rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow desk-shadow flex items-center justify-center relative overflow-hidden">
                {/* Subtle paper texture */}
                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
                  backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px), repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)'
                }} />
                <div className="relative z-10 w-full h-full">
                  <ProductMockup />
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Premium quality materials in a beautiful presentation box, ready to start your detective journey
              </p>
            </div>

            {/* Product Details */}
            <div className="space-y-8">
              {/* Price */}
              <div>
                <p className="text-sm text-muted-foreground mb-2">SPECIAL PRICE</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold typewriter-text text-accent">$49.99</span>
                  <span className="text-xl text-muted-foreground line-through">$79.99</span>
                </div>
                <p className="text-sm text-green-600 font-semibold mt-2">Save $30 - Limited Time Offer!</p>
              </div>

              {/* What's Included */}
              <div>
                <h3 className="text-xl font-bold mb-4 typewriter-text">What's Included</h3>
                <div className="space-y-3">
                  {kitContents.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <Check size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-foreground">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Security Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Lock size={18} className="text-blue-600" />
                  <span className="font-semibold text-blue-900">Secure Checkout</span>
                </div>
                <p className="text-sm text-blue-800">
                  Your payment information is encrypted and secure. We use industry-standard SSL encryption.
                </p>
              </div>

              {/* Trust Signals */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
                <div className="text-center">
                  <div className="text-2xl mb-2">🔒</div>
                  <p className="text-xs font-semibold text-foreground">SSL Secure</p>
                  <p className="text-xs text-muted-foreground">Payment</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl mb-2">↩️</div>
                  <p className="text-xs font-semibold text-foreground">30-Day</p>
                  <p className="text-xs text-muted-foreground">Money-Back</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl mb-2">🚚</div>
                  <p className="text-xs font-semibold text-foreground">Fast</p>
                  <p className="text-xs text-muted-foreground">Shipping</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Checkout Section */}
      <section className="py-16 md:py-24 bg-popover/30">
        <div className="container max-w-2xl">
          <div className="bg-card rounded-lg border-2 border-border p-8 shadow-lg">
            <h2 className="text-2xl font-bold mb-2 typewriter-text">Complete Your Order</h2>
            <p className="text-muted-foreground mb-6">
              Fill in your details to receive your Detective Onion kit
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-semibold mb-2">Full Name *</label>
                <Input
                  type="text"
                  name="fullName"
                  placeholder="Your full name"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                  className="w-full focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-semibold mb-2">Email Address *</label>
                <Input
                  type="email"
                  name="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-semibold mb-2">Phone Number *</label>
                <Input
                  type="tel"
                  name="phone"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
                />
              </div>

              {/* Card Number */}
              <div>
                <label className="block text-sm font-semibold mb-2">Card Number *</label>
                <Input
                  type="text"
                  name="cardNumber"
                  placeholder="4111 1111 1111 1111"
                  value={formData.cardNumber}
                  onChange={handleInputChange}
                  required
                  maxLength={19}
                  className="w-full font-mono focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary"
                />
              </div>

              {/* Parental Gate */}
              <div className="border-2 border-dashed border-accent bg-accent/5 rounded-lg p-6 text-center">
                <p className="text-lg font-bold typewriter-text text-accent mb-2">🚨 PARENTAL GATE 🚨</p>
                <p className="text-sm font-semibold text-foreground mb-3">
                  Junior Detective: Stop! Ask your parents to complete this mission.
                </p>
                <p className="text-xs text-muted-foreground">
                  This is a real purchase. Parents must review and approve before proceeding.
                </p>
              </div>

              {/* Parent Reminder */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-900 font-semibold mb-1">👨‍👩‍👧 Parents, Please Note:</p>
                <p className="text-sm text-yellow-800">
                  If your child is entering this information, please review it before completing the purchase. This is a real transaction.
                </p>
              </div>

              {/* Security Badges */}
              <div className="flex items-center justify-center gap-4 py-4 border-t border-b border-border">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Shield size={18} className="text-green-600" />
                  <span>SSL Secure</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Lock size={18} className="text-green-600" />
                  <span>Encrypted</span>
                </div>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isProcessing || !formData.fullName || !formData.email || !formData.phone || !formData.cardNumber}
                size="lg"
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold button-typewriter"
                onClick={() => triggerInteraction('stamp')}
              >
                {isProcessing ? 'Processing...' : 'I Want to Start Investigating! (Secure Payment)'}
              </Button>

              <p className="text-xs text-center text-muted-foreground">
                By clicking the button above, you agree to our Terms of Use and Privacy Policy
              </p>
            </form>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl font-bold mb-12 text-center typewriter-text">Why Choose Detective Onion?</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
              <div className="text-5xl mb-4">🎓</div>
              <h3 className="font-bold text-lg mb-2">Educational</h3>
              <p className="text-sm text-muted-foreground">
                Designed by educators to teach real scientific concepts through hands-on exploration
              </p>
            </div>

            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
              <div className="text-5xl mb-4">👨‍👩‍👧</div>
              <h3 className="font-bold text-lg mb-2">Family Time</h3>
              <p className="text-sm text-muted-foreground">
                Screen-free activities that bring families together for meaningful quality time
              </p>
            </div>

            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
              <div className="text-5xl mb-4">✅</div>
              <h3 className="font-bold text-lg mb-2">Safe & Tested</h3>
              <p className="text-sm text-muted-foreground">
                All materials are food-grade or household items. Every experiment has been tested with children
              </p>
            </div>
          </div>
        </div>
      </section>

      <StripePaymentModal
        isOpen={isPaymentModalOpen}
        onClose={handlePaymentClose}
        amount={49.99}
      />
    </div>
  );
}
