import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { updateSEOMeta, seoConfig } from '@/lib/seo';

export default function Terms() {
  const { t } = useTranslation();

  useEffect(() => {
    updateSEOMeta(seoConfig.terms || {
      title: 'Terms of Use | Detective Onion',
      description: 'Read our Terms of Use for Detective Onion Agency website and science kits.'
    });
  }, []);

  return (
    <main className="min-h-screen bg-[#f4f1ea] font-sans text-stone-800 py-12 px-4">
      {/* Texture Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] mix-blend-multiply bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')]"></div>

      <div className="container mx-auto max-w-3xl bg-white p-8 rounded-sm shadow-md border border-stone-200 relative z-10">
        <h1 className="text-3xl md:text-4xl font-bold font-typewriter mb-6 border-b-4 border-stone-800 pb-4">
          {t('terms.title')}
        </h1>
        
        <div className="space-y-6 text-sm md:text-base leading-relaxed">
          <p className="italic text-stone-500">
            {t('common.last_updated')}: {new Date().toLocaleDateString()}
          </p>

          {/* Section 1 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              1. {t('terms.section1_title')}
            </h2>
            <p>{t('terms.section1_content')}</p>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              2. {t('terms.section2_title')}
            </h2>
            <p>{t('terms.section2_content')}</p>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              3. {t('terms.section3_title')}
            </h2>
            <p>{t('terms.section3_content')}</p>
          </section>

          {/* Section 4 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              4. {t('terms.section4_title')}
            </h2>
            <p>{t('terms.section4_content')}</p>
          </section>

          {/* Section 5 */}
          <section>
            <h2 className="text-xl font-bold font-typewriter mb-3 text-primary">
              5. {t('terms.section5_title')}
            </h2>
            <p>{t('terms.section5_content')}</p>
          </section>
        </div>
      </div>
    </main>
  );
}
