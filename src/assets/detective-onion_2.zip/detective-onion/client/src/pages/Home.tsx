import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { triggerInteraction } from '@/lib/interactions';
import { updateSEOMeta, seoConfig } from '@/lib/seo';
import { useTranslation } from 'react-i18next';

export default function Home() {
  const { t } = useTranslation();
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const [caseCount] = useState(1247);

  useEffect(() => {
    updateSEOMeta(seoConfig.home);
  }, []);

  const deskItems = [
    {
      id: 'coffee',
      icon: '☕',
      label: 'Coffee Cup',
      description: 'Lukewarm and full of mysteries...',
    },
    {
      id: 'magnifier',
      icon: '🔍',
      label: 'Magnifying Glass',
      description: 'For examining the smallest clues',
    },
    {
      id: 'casefile',
      icon: '📁',
      label: 'Case Files',
      description: 'Hundreds of solved mysteries',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - Detective's Desk */}
      <section className="relative py-16 md:py-24 overflow-hidden">
        {/* Dramatic background with warm lighting effect */}
        <div className="absolute inset-0 warm-light pointer-events-none" />
        
        <div className="container relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <div className="space-y-6">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary typewriter-text leading-tight">
                  {t('home.hero_title')}
                </h1>
                <p className="text-xl text-foreground">
                  {t('home.hero_subtitle')}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/shop">
                  <a>
                    <Button
                      size="lg"
                      className="bg-accent hover:bg-accent/90 text-accent-foreground w-full sm:w-auto button-typewriter"
                      onClick={() => triggerInteraction('stamp')}
                    >
                      {t('home.cta_join')}
                      <ArrowRight className="ml-2" size={20} />
                    </Button>
                  </a>
                </Link>
                <Link href="/cases">
                  <a>
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-2 border-primary text-primary hover:bg-primary/10 w-full sm:w-auto"
                    >
                      {t('home.cta_explore')}
                    </Button>
                  </a>
                </Link>
              </div>

              {/* Social Proof */}
              <div className="pt-4 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  <span className="font-bold text-primary">{caseCount.toLocaleString()}</span> {t('home.detectives_count')}
                </p>
              </div>
            </div>

            {/* Right: Interactive Desk */}
            <div className="relative h-96 md:h-[500px] bg-gradient-to-br from-yellow-100 to-amber-50 rounded-lg bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow desk-shadow">
              {/* Desk surface */}
              <div className="absolute inset-0 rounded-lg overflow-hidden">
                {/* Wood texture overlay */}
                <div className="absolute inset-0 opacity-10 bg-gradient-to-b from-amber-900 to-amber-700" />
                
                {/* Interactive items */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-full h-full flex items-center justify-center">
                    {/* Coffee Cup - Top Left */}
                    <button
                      onClick={() => {
                        setActiveItem('coffee');
                        triggerInteraction('typewriter');
                      }}
                      className={`absolute top-12 left-8 transition-all transform hover:scale-110 ${
                        activeItem === 'coffee' ? 'scale-125' : 'hover:scale-105'
                      }`}
                      style={{
                        filter: 'drop-shadow(0 10px 15px rgba(0, 0, 0, 0.3)) drop-shadow(0 0 20px rgba(139, 69, 19, 0.2))'
                      }}
                    >
                      <div className="text-6xl md:text-7xl">☕</div>
                      {activeItem === 'coffee' && (
                        <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-3 py-1 rounded text-sm whitespace-nowrap">
                          Lukewarm mysteries...
                        </div>
                      )}
                    </button>

                    {/* Magnifying Glass - Top Right */}
                    <button
                      onClick={() => {
                        setActiveItem('magnifier');
                        triggerInteraction('typewriter');
                      }}
                      className={`absolute top-12 right-8 transition-all transform hover:scale-110 ${
                        activeItem === 'magnifier' ? 'scale-125' : 'hover:scale-105'
                      }`}
                      style={{
                        filter: 'drop-shadow(0 10px 15px rgba(0, 0, 0, 0.3)) drop-shadow(0 0 20px rgba(100, 150, 200, 0.2))'
                      }}
                    >
                      <div className="text-6xl md:text-7xl">🔍</div>
                      {activeItem === 'magnifier' && (
                        <div className="absolute top-full mt-2 right-0 bg-primary text-primary-foreground px-3 py-1 rounded text-sm whitespace-nowrap">
                          For examining clues
                        </div>
                      )}
                    </button>

                    {/* Case File - Center */}
                    <button
                      onClick={() => {
                        setActiveItem('casefile');
                        triggerInteraction('stamp');
                      }}
                      className={`relative transition-all transform hover:scale-110 ${
                        activeItem === 'casefile' ? 'scale-125' : 'hover:scale-105'
                      }`}
                      style={{
                        filter: 'drop-shadow(0 15px 25px rgba(0, 0, 0, 0.4)) drop-shadow(0 0 30px rgba(180, 83, 9, 0.3))'
                      }}
                    >
                      <div className="bg-yellow-50 border-2 border-yellow-600 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow relative p-6 min-w-max">
                        <div className="text-4xl mb-2">📁</div>
                        <div className="text-sm font-bold typewriter-text text-yellow-900">CASE FILE</div>
                        <div className="text-xs text-yellow-800">CONFIDENTIAL</div>
                      </div>
                      {activeItem === 'casefile' && (
                        <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-3 py-1 rounded text-sm whitespace-nowrap">
                          Hundreds of mysteries
                        </div>
                      )}
                    </button>

                    {/* Ink Stamp - Bottom Right */}
                    <div className="absolute bottom-8 right-8 opacity-20 transform -rotate-12 text-6xl">
                      🔴
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Cases Preview */}
      <section className="py-16 md:py-24 bg-popover/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 typewriter-text">Latest Cases</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Check out the most recent mysteries solved by our detective team
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: 'The Baking Soda Eruption',
                suspect: 'Baking Soda & Vinegar',
                scene: 'Kitchen Counter',
              },
              {
                title: 'The Invisible Ink Mystery',
                suspect: 'Lemon Juice',
                scene: 'Detective\'s Desk',
              },
              {
                title: 'The Floating Egg Enigma',
                suspect: 'Salt Water Solution',
                scene: 'Glass of Water',
              },
            ].map((caseItem, idx) => (
              <Link key={idx} href="/cases">
                <a className="bg-yellow-50 border-2 border-yellow-600 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow relative p-6 hover:shadow-xl transition-shadow">
                  <div className="mb-4">
                    <span className="inline-block stamp confidential mb-3">CASE #{1001 + idx}</span>
                  </div>
                  <h3 className="font-bold text-lg mb-3 typewriter-text text-yellow-900">
                    {caseItem.title}
                  </h3>
                  <div className="space-y-2 text-sm text-yellow-800">
                    <p>
                      <span className="font-semibold">Suspect:</span> {caseItem.suspect}
                    </p>
                    <p>
                      <span className="font-semibold">Scene:</span> {caseItem.scene}
                    </p>
                  </div>
                  <div className="mt-4 pt-4 border-t border-yellow-200">
                    <span className="text-xs font-bold text-yellow-900">READ FULL REPORT →</span>
                  </div>
                </a>
              </Link>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/cases">
              <a>
                <Button variant="outline" size="lg" className="border-2 border-primary">
                  View All Cases
                  <ArrowRight className="ml-2" size={20} />
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* About Detective Onion Preview */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="text-6xl text-center">🧅</div>
            </div>
            <div className="order-1 lg:order-2 space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold typewriter-text">Meet Detective Onion</h2>
              <p className="text-lg text-foreground">
                Once a humble vegetable in a farmer's market, Detective Onion discovered a passion for science and mystery-solving. With tears of curiosity and layers of knowledge, this detective has cracked hundreds of kitchen cases.
              </p>
              <p className="text-lg text-muted-foreground">
                Joined by Carrot Assistant and Professor Potato, Detective Onion believes that asking "Why?" is the most powerful tool in any kitchen.
              </p>
              <Link href="/about">
                <a>
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Learn Our Story
                    <ArrowRight className="ml-2" size={20} />
                  </Button>
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg mx-4 md:mx-0">
        <div className="container text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold typewriter-text">Ready to Become a Detective?</h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            Get your complete detective kit and start solving mysteries in your own kitchen today.
          </p>
          <Link href="/shop">
            <a>
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground button-typewriter">
                Get Your Kit Now
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
