import { useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { updateSEOMeta, seoConfig } from '@/lib/seo';
import { useTranslation } from 'react-i18next';

export default function About() {
  const { t } = useTranslation();
  useEffect(() => {
    updateSEOMeta(seoConfig.about);
  }, []);
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container text-center space-y-6">
          <div className="text-8xl mb-4">🧅</div>
          <h1 className="text-4xl md:text-5xl font-bold typewriter-text">{t('header.title')}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            {t('about.origin_title')}
          </p>
        </div>
      </section>

      {/* Origin Story */}
      <section className="py-16 md:py-24">
        <div className="container max-w-3xl">
          <div className="space-y-8">
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h2 className="text-3xl font-bold mb-4 typewriter-text">{t('about.origin_title')}</h2>
              <p className="text-lg text-foreground mb-4">
                {t('about.origin_text')}
              </p>
            </div>

            {/* Core Belief */}
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-accent bg-accent/5">
              <h3 className="text-2xl font-bold mb-4 typewriter-text text-accent">Our Core Belief</h3>
              <p className="text-lg font-semibold text-foreground mb-3">
                "We believe that asking 'Why?' is the most powerful tool in any kitchen."
              </p>
              <p className="text-foreground">
                Science isn't just for laboratories. It's in your refrigerator, your pantry, and your sink. By asking questions and running experiments, children develop critical thinking skills, creativity, and a lifelong love of learning.
              </p>
            </div>

            {/* Team */}
            <div>
              <h2 className="text-3xl font-bold mb-8 typewriter-text">The Detective Agency Team</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Detective Onion */}
                <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
                  <div className="text-6xl mb-4">🧅</div>
                  <h3 className="text-xl font-bold mb-2">Detective Onion</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Lead Investigator
                  </p>
                  <p className="text-sm">
                    The visionary founder with layers of knowledge and a passion for uncovering kitchen secrets. Known for making everyone cry with laughter.
                  </p>
                </div>

                {/* Carrot Assistant */}
                <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
                  <div className="text-6xl mb-4">🥕</div>
                  <h3 className="text-xl font-bold mb-2">Carrot Assistant</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Field Agent
                  </p>
                  <p className="text-sm">
                    Sharp-eyed and detail-oriented, Carrot Assistant never misses a clue. Specializes in color-changing experiments and nutritional mysteries.
                  </p>
                </div>

                {/* Professor Potato */}
                <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow text-center">
                  <div className="text-6xl mb-4">🥔</div>
                  <h3 className="text-xl font-bold mb-2">Professor Potato</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Chief Scientist
                  </p>
                  <p className="text-sm">
                    A grounded expert in chemistry and physics. Professor Potato explains the "why" behind every experiment with patience and humor.
                  </p>
                </div>
              </div>
            </div>

            {/* Mission */}
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-secondary bg-secondary/5">
              <h3 className="text-2xl font-bold mb-4 typewriter-text text-secondary">Our Mission</h3>
              <ul className="space-y-3 text-foreground">
                <li className="flex gap-3">
                  <span className="text-2xl">🔍</span>
                  <span>
                    <strong>Foster Scientific Curiosity:</strong> Help children see science as an adventure, not a chore.
                  </span>
                </li>
                <li className="flex gap-3">
                  <span className="text-2xl">🧠</span>
                  <span>
                    <strong>Develop Critical Thinking:</strong> Teach kids to ask questions, form hypotheses, and test ideas.
                  </span>
                </li>
                <li className="flex gap-3">
                  <span className="text-2xl">👨‍👩‍👧‍👦</span>
                  <span>
                    <strong>Build Family Connections:</strong> Create opportunities for meaningful screen-free time together.
                  </span>
                </li>
                <li className="flex gap-3">
                  <span className="text-2xl">🌍</span>
                  <span>
                    <strong>Inspire Lifelong Learners:</strong> Plant seeds of wonder that grow into a passion for understanding the world.
                  </span>
                </li>
              </ul>
            </div>

            {/* Why We Do This */}
            <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <h3 className="text-2xl font-bold mb-4 typewriter-text">Why We Do This</h3>
              <p className="text-lg text-foreground mb-4">
                In a world of screens and distractions, children need experiences that spark genuine curiosity. They need to see, touch, and understand the science that surrounds them every day.
              </p>
              <p className="text-lg text-foreground mb-4">
                Detective Onion Agency exists to prove that science is everywhere—in your kitchen, in your garden, in your own backyard. And when children understand that, they understand that they can learn anything, solve anything, and become anything they dream.
              </p>
              <p className="text-lg text-foreground">
                Every experiment solved is a child who learned to think critically. Every mystery uncovered is a family that spent quality time together. Every detective trained is a future scientist, engineer, or problem-solver who will change the world.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/20 to-accent/20">
        <div className="container text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold typewriter-text">Join Our Detective Agency</h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            Get your complete detective kit and start solving mysteries today.
          </p>
          <Link href="/shop">
            <a>
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground button-typewriter">
                Get Started
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
