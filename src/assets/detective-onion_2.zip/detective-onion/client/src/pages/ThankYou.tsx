import { useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { updateSEOMeta, seoConfig } from '@/lib/seo';

export default function ThankYou() {
  useEffect(() => {
    updateSEOMeta(seoConfig.thankYou);
  }, []);
  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-16">
      <div className="container max-w-2xl">
        <div className="text-center space-y-8">
          {/* APPROVED Stamp */}
          <div className="relative inline-block w-full">
            <div className="flex justify-center">
              <div className="stamp approved text-6xl font-bold animate-bounce">
                APPROVED
              </div>
            </div>
          </div>

          {/* Main Message */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold typewriter-text">
              Welcome to the Detective Onion Agency!
            </h1>
            <p className="text-xl text-muted-foreground">
              Your detective kit is on its way. Get ready to solve some amazing mysteries!
            </p>
          </div>

          {/* Confirmation Details */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow bg-green-50 border-green-600">
            <h2 className="font-bold text-lg mb-4 typewriter-text">What Happens Next?</h2>
            <div className="space-y-3 text-left">
              <div className="flex gap-3">
                <span className="text-2xl">📦</span>
                <div>
                  <p className="font-semibold">Your Kit is Being Prepared</p>
                  <p className="text-sm text-muted-foreground">
                    We're carefully packing your complete detective kit with all materials and guides.
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-2xl">📧</span>
                <div>
                  <p className="font-semibold">Check Your Email</p>
                  <p className="text-sm text-muted-foreground">
                    You'll receive a confirmation email with tracking information and setup instructions.
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-2xl">🚚</span>
                <div>
                  <p className="font-semibold">Fast Shipping</p>
                  <p className="text-sm text-muted-foreground">
                    Most orders ship within 2-3 business days. You'll have your kit soon!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* While You Wait Section */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <h2 className="font-bold text-lg mb-4 typewriter-text">While You Wait...</h2>
            <p className="text-foreground mb-4">
              Start preparing for your first investigation! Here's an easy experiment you can do right now with items from your kitchen:
            </p>

            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 text-left mb-4">
              <h3 className="font-bold text-yellow-900 mb-2">Quick Experiment: The Invisible Ink Mystery</h3>
              <p className="text-sm text-yellow-800 mb-3">
                Write a secret message with lemon juice on white paper. Let it dry completely. Heat the paper gently with a lamp to reveal the hidden message!
              </p>
              <p className="text-xs text-yellow-700">
                <strong>Why it works:</strong> Lemon juice oxidizes when heated, turning brown and revealing your secret message.
              </p>
            </div>

            <Link href="/cases">
              <a>
                <Button variant="outline" size="sm" className="w-full border-2 border-primary text-primary">
                  Explore More Experiments
                  <ArrowRight className="ml-2" size={16} />
                </Button>
              </a>
            </Link>
          </div>

          {/* Join Community */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-accent bg-accent/5">
            <h2 className="font-bold text-lg mb-4 typewriter-text">Join Our Detective Community</h2>
            <p className="text-foreground mb-4">
              Connect with other young detectives, share your experiment photos, and get exclusive tips!
            </p>
            <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground button-typewriter">
                Join WhatsApp Community
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </a>
          </div>

          {/* Contact Support */}
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Questions or need help? We're here to assist!
            </p>
            <Link href="/contact">
              <a className="text-primary hover:underline font-semibold">
                Contact Our Detective Team
              </a>
            </Link>
          </div>

          {/* Return Home */}
          <Link href="/">
            <a>
              <Button variant="outline" size="lg" className="border-2 border-primary">
                Return to Agency
              </Button>
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
