import { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { updateSEOMeta, seoConfig } from '@/lib/seo';
import { useTranslation } from 'react-i18next';

interface CaseReport {
  id: number;
  title: string;
  suspect: string;
  scene: string;
  experiment: string;
  conclusion: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  tags: string[];
}

const cases: CaseReport[] = [
  {
    id: 1001,
    title: 'The Baking Soda Eruption',
    suspect: 'Baking Soda & Vinegar',
    scene: 'Kitchen Counter',
    experiment:
      'Mix baking soda in a cup, add food coloring and dish soap, then pour vinegar into the mixture and watch the eruption!',
    conclusion:
      'This is an acid-base reaction. Vinegar (acetic acid) reacts with baking soda (sodium bicarbonate) to produce carbon dioxide gas, which creates the bubbling effect.',
    difficulty: 'Easy',
    tags: ['Chemistry', 'Reactions', 'Beginner'],
  },
  {
    id: 1002,
    title: 'The Invisible Ink Mystery',
    suspect: 'Lemon Juice',
    scene: 'Detective\'s Desk',
    experiment:
      'Write a secret message with lemon juice on white paper. Let it dry completely. Heat the paper gently with a lamp or iron to reveal the hidden message.',
    conclusion:
      'Lemon juice oxidizes when heated, turning brown. This happens because the juice contains carbon compounds that darken when exposed to heat.',
    difficulty: 'Easy',
    tags: ['Chemistry', 'Heat', 'Beginner'],
  },
  {
    id: 1003,
    title: 'The Floating Egg Enigma',
    suspect: 'Salt Water Solution',
    scene: 'Glass of Water',
    experiment:
      'Fill a glass with water and add salt until an egg floats. Gradually add fresh water to make the egg sink and rise again.',
    conclusion:
      'Density determines whether objects float or sink. Salt water is denser than fresh water, so the egg floats in salt water but sinks in fresh water.',
    difficulty: 'Easy',
    tags: ['Physics', 'Density', 'Beginner'],
  },
  {
    id: 1004,
    title: 'The Milk Color Explosion',
    suspect: 'Food Coloring & Dish Soap',
    scene: 'Plate of Milk',
    experiment:
      'Pour milk on a plate, add drops of food coloring, then touch the surface with a soap-dipped cotton swab and watch the colors explode.',
    conclusion:
      'Dish soap breaks the surface tension of milk, causing the food coloring to move rapidly. This demonstrates molecular interactions.',
    difficulty: 'Easy',
    tags: ['Chemistry', 'Surface Tension', 'Beginner'],
  },
  {
    id: 1005,
    title: 'The Rainbow Density Tower',
    suspect: 'Sugar & Water',
    scene: 'Tall Glass',
    experiment:
      'Create layers of different sugar concentrations in water (from most sugar to least). Carefully pour each layer to create a rainbow effect.',
    conclusion:
      'Different densities create layers that don\'t mix. The densest solution (most sugar) sinks to the bottom, while the least dense floats on top.',
    difficulty: 'Medium',
    tags: ['Chemistry', 'Density', 'Intermediate'],
  },
  {
    id: 1006,
    title: 'The Volcano Reaction',
    suspect: 'Mentos & Diet Cola',
    scene: 'Outdoor Area',
    experiment:
      'Drop Mentos candies into a bottle of diet cola and step back! The reaction creates a spectacular fountain.',
    conclusion:
      'Mentos provides nucleation sites for CO2 bubbles to form rapidly. The rough surface of the candy causes rapid degassing of the carbonated liquid.',
    difficulty: 'Hard',
    tags: ['Chemistry', 'Gas', 'Advanced'],
  },
];

export default function Cases() {
  const { t } = useTranslation();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  useEffect(() => {
    updateSEOMeta(seoConfig.cases);
  }, []);

  const filteredCases = cases.filter((c) => {
    if (selectedDifficulty && c.difficulty !== selectedDifficulty) return false;
    if (selectedTag && !c.tags.includes(selectedTag)) return false;
    return true;
  });

  const allTags = Array.from(new Set(cases.flatMap((c) => c.tags)));
  const difficulties = ['Easy', 'Medium', 'Hard'];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold typewriter-text">Case Archive</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore our collection of solved kitchen mysteries. Each case is a complete investigation report.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-popover/30 sticky top-24 z-40 border-b border-border">
        <div className="container">
          <div className="space-y-4">
            {/* Difficulty Filter */}
            <div>
              <p className="text-sm font-semibold mb-2">{t('cases.difficulty_label')}</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedDifficulty(null)}
                  className={`px-4 py-2 md:px-3 md:py-1 min-h-11 md:min-h-auto rounded-full text-sm font-medium transition-all ${
                    selectedDifficulty === null
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-foreground hover:bg-muted/80'
                  }`}
                >
                  {t('common.all')}
                </button>
                {difficulties.map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setSelectedDifficulty(diff)}
                    className={`px-4 py-2 md:px-3 md:py-1 min-h-11 md:min-h-auto rounded-full text-sm font-medium transition-all ${
                      selectedDifficulty === diff
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Tag Filter */}
            <div>
              <p className="text-sm font-semibold mb-2">{t('cases.category_label')}</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedTag(null)}
                  className={`px-4 py-2 md:px-3 md:py-1 min-h-11 md:min-h-auto rounded-full text-sm font-medium transition-all ${
                    selectedTag === null
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-foreground hover:bg-muted/80'
                  }`}
                >
                  {t('common.all')}
                </button>
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(tag)}
                    className={`px-4 py-2 md:px-3 md:py-1 min-h-11 md:min-h-auto rounded-full text-sm font-medium transition-all ${
                      selectedTag === tag
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cases Grid */}
      <section className="py-16">
        <div className="container">
          {filteredCases.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">No cases match your filters. Try adjusting them!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredCases.map((caseItem) => {
                const randomRotation = Math.random() * 10 - 5; // Random rotation between -5 and 5 degrees
                return (
                <div key={caseItem.id} className="bg-yellow-50 border-2 border-yellow-600 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow relative p-6 hover:shadow-xl transition-shadow">
                  {/* Header */}
                  <div className="mb-4 flex items-start justify-between">
                    <span className="inline-block stamp confidential text-sm" style={{ transform: `rotate(${randomRotation}deg)` }}>CASE #{caseItem.id}</span>
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded ${
                        caseItem.difficulty === 'Easy'
                          ? 'bg-green-100 text-green-800'
                          : caseItem.difficulty === 'Medium'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {caseItem.difficulty}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-lg mb-3 typewriter-text text-yellow-900">{caseItem.title}</h3>

                  {/* Case Details */}
                  <div className="space-y-2 text-sm text-yellow-800 mb-4">
                    <p>
                      <span className="font-semibold">Suspect:</span> {caseItem.suspect}
                    </p>
                    <p>
                      <span className="font-semibold">Scene:</span> {caseItem.scene}
                    </p>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {caseItem.tags.map((tag) => (
                      <span key={tag} className="text-xs bg-yellow-200 text-yellow-900 px-2 py-1 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Experiment Preview */}
                  <p className="text-sm text-yellow-800 mb-4 line-clamp-2">{caseItem.experiment}</p>

                  {/* Read More */}
                  <div className="pt-4 border-t border-yellow-200">
                    <button className="text-xs font-bold text-yellow-900 hover:text-yellow-700 transition-colors flex items-center gap-1">
                      READ FULL REPORT
                      <ArrowRight size={14} />
                    </button>
                  </div>                </div>
              );
              })}\n            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/20 to-accent/20">
        <div className="container text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold typewriter-text">Ready to Run Your Own Experiments?</h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            Get your complete detective kit with all the materials you need to solve these mysteries and more.
          </p>
          <a href="/shop">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground button-typewriter">
              Get Your Kit
              <ArrowRight className="ml-2" size={20} />
            </Button>
          </a>
        </div>
      </section>
    </div>
  );
}
