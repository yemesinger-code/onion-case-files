import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { updateSEOMeta, seoConfig } from '@/lib/seo';

interface FAQItem {
  question: string;
  answer: string;
}

export default function Parents() {
  const { t } = useTranslation();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useEffect(() => {
    updateSEOMeta(seoConfig.parents);
  }, []);

  // Get FAQ items from translations
  const faqs: FAQItem[] = t('parents.faq_items', { returnObjects: true }) as FAQItem[];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-secondary/10 to-transparent">
        <div className="container text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold typewriter-text">{t('parents.title')}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            {t('parents.header_subtitle')}
          </p>
        </div>
      </section>

      {/* Educational Value */}
      <section className="py-16 md:py-24">
        <div className="container max-w-3xl space-y-12">
          {/* Scientific Literacy */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <h2 className="text-2xl font-bold mb-4 typewriter-text">{t('parents.scientific_literacy_title')}</h2>
            <p className="text-lg text-foreground mb-4">
              {t('parents.scientific_literacy_p1')}
            </p>
            <p className="text-foreground">
              {t('parents.scientific_literacy_p2')}
            </p>
          </div>

          {/* Critical Thinking */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-primary bg-primary/5">
            <h2 className="text-2xl font-bold mb-4 typewriter-text">{t('parents.critical_thinking_title')}</h2>
            <p className="text-lg text-foreground mb-4">
              {t('parents.critical_thinking_p1')}
            </p>
            <p className="text-foreground">
              {t('parents.critical_thinking_p2')}
            </p>
          </div>

          {/* Family Connection */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-accent bg-accent/5">
            <h2 className="text-2xl font-bold mb-4 typewriter-text">{t('parents.family_bonds_title')}</h2>
            <p className="text-lg text-foreground mb-4">
              {t('parents.family_bonds_p1')}
            </p>
            <p className="text-foreground">
              {t('parents.family_bonds_p2')}
            </p>
          </div>

          {/* Confidence & Resilience */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <h2 className="text-2xl font-bold mb-4 typewriter-text">{t('parents.confidence_title')}</h2>
            <p className="text-lg text-foreground mb-4">
              {t('parents.confidence_p1')}
            </p>
            <p className="text-foreground mb-4">
              {t('parents.confidence_p2')}
            </p>
          </div>

          {/* Screen-Free Benefits */}
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-secondary bg-secondary/5">
            <h2 className="text-2xl font-bold mb-4 typewriter-text">{t('parents.screen_free_title')}</h2>
            <p className="text-lg text-foreground mb-4">
              {t('parents.screen_free_p1')}
            </p>
            <p className="text-foreground">
              {t('parents.screen_free_p2')}
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-popover/30">
        <div className="container max-w-3xl">
          <h2 className="text-3xl font-bold mb-12 text-center typewriter-text">{t('parents.faq_title')}</h2>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                <button
                  onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                  className="w-full flex items-start justify-between gap-4 text-left"
                >
                  <h3 className="font-bold text-lg flex-1">{faq.question}</h3>
                  <ChevronDown
                    size={24}
                    className={`flex-shrink-0 transition-transform ${
                      openIndex === idx ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {openIndex === idx && (
                  <div className="mt-4 pt-4 border-t border-border text-foreground">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Getting Started */}
      <section className="py-16 md:py-24">
        <div className="container max-w-3xl">
          <div className="bg-card border-2 border-border rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow border-primary bg-primary/5">
            <h2 className="text-2xl font-bold mb-6 typewriter-text">{t('parents.getting_started_title')}</h2>

            <div className="space-y-6">
              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step1_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step1_text')}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step2_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step2_text')}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step3_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step3_text')}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step4_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step4_text')}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step5_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step5_text')}
                </p>
              </div>

              <div>
                <h3 className="font-bold text-lg mb-2">{t('parents.step6_title')}</h3>
                <p className="text-foreground">
                  {t('parents.step6_text')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/20 to-accent/20">
        <div className="container text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold typewriter-text">{t('parents.ready_title')}</h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            {t('parents.ready_subtitle')}
          </p>
          <a href="/shop">
            <button className="inline-flex items-center gap-2 px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg transition-colors button-typewriter">
              {t('parents.ready_cta')}
              <span>→</span>
            </button>
          </a>
        </div>
      </section>
    </div>
  );
}
