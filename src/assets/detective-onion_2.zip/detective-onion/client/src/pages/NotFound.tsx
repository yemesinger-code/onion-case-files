import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-8 px-4 max-w-2xl">
        {/* Case File Header */}
        <div className="bg-yellow-50 border-2 border-yellow-600 rounded-lg p-8 inline-block mx-auto">
          <div className="text-6xl mb-4">🔍</div>
          <p className="text-sm font-bold typewriter-text text-yellow-900 mb-2">CASE #404</p>
          <p className="text-xs text-yellow-800">UNSOLVED</p>
        </div>

        <div className="space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold typewriter-text text-primary">
            Case Not Found
          </h1>
          <p className="text-xl text-muted-foreground max-w-md mx-auto">
            Detective Onion has searched everywhere, but this page remains a mystery. The trail has gone cold.
          </p>
        </div>

        {/* Navigation Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          <Link href="/">
            <a>
              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                <ArrowLeft className="mr-2" size={20} />
                Back Home
              </Button>
            </a>
          </Link>
          <Link href="/cases">
            <a>
              <Button size="lg" variant="outline" className="w-full border-2 border-primary text-primary hover:bg-primary/10">
                Explore Cases
              </Button>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button size="lg" variant="outline" className="w-full border-2 border-secondary text-secondary hover:bg-secondary/10">
                Report Mystery
              </Button>
            </a>
          </Link>
        </div>

        {/* Helpful Text */}
        <p className="text-sm text-muted-foreground pt-4">
          If you believe this is an error, please{' '}
          <Link href="/contact">
            <a className="text-primary font-semibold hover:underline">contact us</a>
          </Link>
          {' '}and report the mystery.
        </p>
      </div>
    </div>
  );
}
