export interface SEOConfig {
  title: string;
  description: string;
  ogImage?: string;
}

export const seoConfig: Record<string, SEOConfig> = {
  home: {
    title: 'Detective Onion | Science Experiments & Mystery Games for Kids',
    description: 'Solve kitchen mysteries through hands-on science experiments. Screen-free family fun with educational value. Join 1,247+ young detectives.',
    ogImage: 'https://3000-iv67az2p8f1sz8zz1f705-b8fb1283.sg1.manus.computer/detective-onion-hero.jpg',
  },
  about: {
    title: 'About Detective Onion | Meet Our Team of Kitchen Investigators',
    description: 'Learn about Detective Onion, Carrot Assistant, and Professor Potato. Discover the story behind the agency solving kitchen mysteries.',
  },
  cases: {
    title: 'Case Archive | Solved Kitchen Mysteries & Science Experiments',
    description: 'Explore our collection of solved kitchen mysteries. Each case is a complete investigation report with step-by-step experiments.',
  },
  parents: {
    title: 'Parents Zone | Educational Value & FAQ - Detective Onion',
    description: 'Learn how Detective Onion develops critical thinking, encourages screen-free family time, and teaches real science concepts.',
  },
  shop: {
    title: 'Buy Detective Kits | Science Tools for Kids - Detective Onion',
    description: 'Get the Detective Onion Starter Kit. Premium quality materials, 50 experiment guides, and access to our online case archive.',
    ogImage: 'https://3000-iv67az2p8f1sz8zz1f705-b8fb1283.sg1.manus.computer/detective-kit-mockup.jpg',
  },
  contact: {
    title: 'Contact Detective Onion | Report a Mystery or Share Your Experiments',
    description: 'Have a kitchen mystery to report? Share your experiments with our detective community. Get in touch with the Detective Onion Agency.',
  },
  thankYou: {
    title: 'Thank You! Your Detective Kit is On the Way - Detective Onion',
    description: 'Your order has been approved! Check your email for shipping details and exclusive detective tips.',
  },
};

export function updateSEOMeta(config: SEOConfig) {
  // Update title
  document.title = config.title;

  // Update or create meta description
  let metaDescription = document.querySelector('meta[name="description"]');
  if (!metaDescription) {
    metaDescription = document.createElement('meta');
    metaDescription.setAttribute('name', 'description');
    document.head.appendChild(metaDescription);
  }
  metaDescription.setAttribute('content', config.description);

  // Update or create og:title
  let ogTitle = document.querySelector('meta[property="og:title"]');
  if (!ogTitle) {
    ogTitle = document.createElement('meta');
    ogTitle.setAttribute('property', 'og:title');
    document.head.appendChild(ogTitle);
  }
  ogTitle.setAttribute('content', config.title);

  // Update or create og:description
  let ogDescription = document.querySelector('meta[property="og:description"]');
  if (!ogDescription) {
    ogDescription = document.createElement('meta');
    ogDescription.setAttribute('property', 'og:description');
    document.head.appendChild(ogDescription);
  }
  ogDescription.setAttribute('content', config.description);

  // Update or create og:image if provided
  if (config.ogImage) {
    let ogImage = document.querySelector('meta[property="og:image"]');
    if (!ogImage) {
      ogImage = document.createElement('meta');
      ogImage.setAttribute('property', 'og:image');
      document.head.appendChild(ogImage);
    }
    ogImage.setAttribute('content', config.ogImage);
  }
}
