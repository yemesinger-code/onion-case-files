import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      // --- Global ---
      "navHome": "Home",
      "navCases": "Cases",
      "navParents": "Parents",
      "navShop": "Armory",
      "navContact": "Contact",
      
      // --- Home Page ---
      "heroTitle": "There's a Mystery in Your Fridge",
      "heroSubtitle": "Let's solve it together. Welcome to the Detective Onion Agency.",
      "joinAgency": "Join the Agency",
      "exploreCases": "Explore Cases",
      "activeDetectives": "{{count}} young detectives active",
      "latestCasesTitle": "Latest Cases",
      "latestCasesSubtitle": "Recent mysteries solved by our team",
      "viewAllCases": "View All Cases",
      "meetOnionTitle": "Meet Detective Onion",
      "meetOnionDesc1": "Once a humble vegetable, now a master of science.",
      "meetOnionDesc2": "Asking \"Why?\" is the most powerful tool.",
      "learnStory": "Learn Our Story",
      "readyToBecome": "Ready to Become a Detective?",
      "getKitDesc": "Get your complete kit today.",
      "getKitBtn": "Get Your Kit Now",
      
      // Items
      "coffeeLabel": "Coffee Cup", "coffeeDesc": "Lukewarm mysteries...",
      "magnifierLabel": "Magnifier", "magnifierDesc": "Examining clues",
      "caseFileLabel": "Files", "caseFileDesc": "Solved mysteries",

      // --- Cases Page ---
      "caseArchiveTitle": "Case Archive",
      "caseArchiveDesc": "Explore our collection of solved kitchen mysteries.",
      "caseNum": "CASE #{{id}}",
      "suspectLabel": "Suspect:",
      "sceneLabel": "Scene:",
      "readFullReport": "READ FULL REPORT",
      "noCasesFound": "No cases found.",
      
      // --- Shop Page ---
      "armoryTitle": "The Armory",
      "armorySubtitle": "Equipment for certified investigators",
      "starterKit": "Detective Onion Starter Kit",
      "kitSubtitle": "Complete Investigation Set",
      "kitDesc": "Premium quality materials in a presentation box.",
      "specialPrice": "SPECIAL PRICE",
      "saveAmount": "Save $30 - Limited Time!",
      "whatsIncluded": "What's Included",
      "itemBadge": "Detective Badge & ID",
      "itemMagnifier": "Premium Magnifying Glass",
      "itemNotebook": "Suspect Log Notebook",
      "itemTestTubes": "3x Test Tubes (Plastic)",
      "itemPipette": "Dropper Pipette",
      "itemSecret": "Secret Message Pen (UV)",
      "parentalGateTitle": "Stop! Identification Required",
      "parentalGateText": "Hey Junior Detective, this part is for the Chief of Police (Mom or Dad). Ask an adult to order.",
      "authorizeBtn": "Authorize Funding",
      "parentsOnly": "(Parents Only)",

      // --- Contact Page ---
      "contactTitle": "Secure Line",
      "contactSubtitle": "Report a mystery or submit your findings to HQ.",
      "submitEvidence": "Submit Evidence",
      "sendMessage": "Send Message",
      "nameLabel": "Agent Name",
      "emailLabel": "Parent's Email",
      "messageLabel": "Mission Report",
      "uploadZone": "Drop Evidence Files Here",
      "uploadSafety": "All files are classified and reviewed by HQ.",

      // --- Parents Page ---
      "parentsTitle": "Chief of Police Zone",
      "parentsSubtitle": "Why we do what we do (The Educational Value)",
      "eduValueTitle": "Building Scientific Literacy",
      "eduValueDesc": "We turn 'messing around' into structured scientific inquiry.",
      "criticalThinking": "Critical Thinking",
      "criticalDesc": "Kids learn to observe, hypothesize, and deduce.",
      "screenFree": "Screen-Free Fun",
      "screenFreeDesc": "100% tactile, hands-on experience.",

      // --- Data ---
      "casesList": [
        {
          "id": 1001, "title": "The Baking Soda Eruption",
          "suspect": "Baking Soda & Vinegar", "scene": "Kitchen Counter",
          "experiment": "Mix baking soda, food coloring, dish soap, and vinegar!",
          "difficulty": "Easy", "tags": ["Chemistry"]
        },
        {
          "id": 1002, "title": "The Invisible Ink",
          "suspect": "Lemon Juice", "scene": "Desk",
          "experiment": "Write with lemon juice, let dry, heat to reveal.",
          "difficulty": "Easy", "tags": ["Chemistry"]
        },
        {
          "id": 1003, "title": "The Floating Egg",
          "suspect": "Salt Water", "scene": "Glass",
          "experiment": "Add salt to water until an egg floats.",
          "difficulty": "Easy", "tags": ["Physics"]
        }
      ]
    }
  },
  he: {
    translation: {
      // --- Global ---
      "navHome": "ראשי",
      "navCases": "תיקים",
      "navParents": "הורים",
      "navShop": "המפסנאות",
      "navContact": "צור קשר",

      // --- Home Page ---
      "heroTitle": "יש תעלומה בתוך המקרר שלך",
      "heroSubtitle": "בואו נפתור אותה יחד. ברוכים הבאים לסוכנות הבלש בצלי.",
      "joinAgency": "הצטרפו לסוכנות",
      "exploreCases": "חקרו תיקים",
      "activeDetectives": "{{count}} בלשים צעירים פעילים",
      "latestCasesTitle": "תיקים אחרונים",
      "latestCasesSubtitle": "תעלומות שפוצחו לאחרונה על ידי הצוות",
      "viewAllCases": "לכל התיקים",
      "meetOnionTitle": "הכירו את הבלש בצלי",
      "meetOnionDesc1": "פעם ירק צנוע בשוק, היום חוקר מדע מדופלם.",
      "meetOnionDesc2": "לשאול \"למה?\" זה הכלי הכי חזק במטבח.",
      "learnStory": "הסיפור שלנו",
      "readyToBecome": "מוכנים להפוך לבלשים?",
      "getKitDesc": "הזמינו את הערכה והתחילו לחקור.",
      "getKitBtn": "הזמינו ערכה עכשיו",

      // Items
      "coffeeLabel": "ספל קפה", "coffeeDesc": "תעלומות פושרות...",
      "magnifierLabel": "זכוכית מגדלת", "magnifierDesc": "לבחינת רמזים",
      "caseFileLabel": "תיקים", "caseFileDesc": "תעלומות פתורות",

      // --- Cases Page ---
      "caseArchiveTitle": "ארכיון התיקים",
      "caseArchiveDesc": "חקרו את אוסף התעלומות שלנו. כל תיק הוא דוח חקירה מלא.",
      "caseNum": "תיק #{{id}}",
      "suspectLabel": "חשוד:",
      "sceneLabel": "זירה:",
      "readFullReport": "קרא דוח מלא",
      "noCasesFound": "לא נמצאו תיקים.",

      // --- Shop Page ---
      "armoryTitle": "המפסנאות",
      "armorySubtitle": "ציוד לחוקרים מוסמכים בלבד",
      "starterKit": "ערכת הבלש בצלי - למתחילים",
      "kitSubtitle": "ערכת חקירה מלאה",
      "kitDesc": "חומרים איכותיים בקופסה מהודרת, מוכנים לפעולה.",
      "specialPrice": "מחיר מיוחד",
      "saveAmount": "חיסכון של ₪30 - לזמן מוגבל!",
      "whatsIncluded": "מה בערכה?",
      "itemBadge": "תג בלש ותעודת סוכן",
      "itemMagnifier": "זכוכית מגדלת איכותית",
      "itemNotebook": "פנקס חשודים",
      "itemTestTubes": "3 מבחנות (פלסטיק בטיחותי)",
      "itemPipette": "פיפטה (טפטפת)",
      "itemSecret": "עט מסרים סודיים (UV)",
      "parentalGateTitle": "עצור! נדרש זיהוי",
      "parentalGateText": "היי בלש צעיר, החלק הזה מיועד למפקד המשטרה (אבא או אמא). קרא למבוגר כדי להזמין.",
      "authorizeBtn": "אישור תקציב",
      "parentsOnly": "(להורים בלבד)",

      // --- Contact Page ---
      "contactTitle": "קו מאובטח",
      "contactSubtitle": "דווח על תעלומה או שלח ממצאים למפקדה.",
      "submitEvidence": "הגשת ראיות",
      "sendMessage": "שלח הודעה",
      "nameLabel": "שם הסוכן",
      "emailLabel": "מייל הורים",
      "messageLabel": "דוח משימה",
      "uploadZone": "גרור קבצי ראיות לכאן",
      "uploadSafety": "כל הקבצים מסווגים ועוברים בדיקת מפקדה.",

      // --- Parents Page ---
      "parentsTitle": "אזור מפקד המשטרה",
      "parentsSubtitle": "למה אנחנו עושים את זה? (הערך החינוכי)",
      "eduValueTitle": "בניית אוריינות מדעית",
      "eduValueDesc": "אנחנו הופכים 'בלאגן במטבח' לחקירה מדעית מובנית.",
      "criticalThinking": "חשיבה ביקורתית",
      "criticalDesc": "ילדים לומדים לצפות, לשער השערות ולהסיק מסקנות.",
      "screenFree": "זמן איכות ללא מסכים",
      "screenFreeDesc": "100% חוויה פיזית ומוחשית.",

      // --- Data ---
      "casesList": [
        {
          "id": 1001, "title": "התפרצות הסודה לשתייה",
          "suspect": "סודה לשתייה וחומץ", "scene": "שיש במטבח",
          "experiment": "ערבבו סודה לשתייה, צבע מאכל, סבון וחומץ - וצפו בהתפרצות!",
          "difficulty": "קל", "tags": ["כימיה"]
        },
        {
          "id": 1002, "title": "תעלומת הדיו הבלתי נראית",
          "suspect": "מיץ לימון", "scene": "שולחן עבודה",
          "experiment": "כתבו במיץ לימון, ייבשו וחממו כדי לחשוף את המסר.",
          "difficulty": "קל", "tags": ["כימיה"]
        },
        {
          "id": 1003, "title": "חידת הביצה הצפה",
          "suspect": "מי מלח", "scene": "כוס מים",
          "experiment": "הוסיפו מלח למים עד שהביצה תצוף.",
          "difficulty": "קל", "tags": ["פיזיקה"]
        }
      ]
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'he', // קבענו עברית כברירת מחדל
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;