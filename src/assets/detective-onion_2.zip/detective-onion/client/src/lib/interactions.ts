/**
 * Detective Onion Interaction Utilities
 * Handles micro-interactions like typewriter sounds and visual feedback
 */

/**
 * Play a subtle typewriter sound effect
 * Uses Web Audio API to generate a simple click sound
 */
export function playTypewriterSound() {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Short click sound
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.05);
  } catch (e) {
    // Silently fail if audio context is not available
    console.debug('Audio context not available for typewriter sound');
  }
}

/**
 * Play a stamp sound effect
 */
export function playStampSound() {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Lower frequency for stamp sound
    oscillator.frequency.value = 400;
    oscillator.type = 'square';

    gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.1);
  } catch (e) {
    console.debug('Audio context not available for stamp sound');
  }
}

/**
 * Trigger haptic feedback if available
 */
export function triggerHapticFeedback() {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    navigator.vibrate(10);
  }
}

/**
 * Combine all interaction feedback
 */
export function triggerInteraction(type: 'typewriter' | 'stamp' | 'click' = 'typewriter') {
  switch (type) {
    case 'typewriter':
      playTypewriterSound();
      break;
    case 'stamp':
      playStampSound();
      triggerHapticFeedback();
      break;
    case 'click':
      playTypewriterSound();
      triggerHapticFeedback();
      break;
  }
}
