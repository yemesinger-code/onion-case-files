# Detective Onion Website - Project TODO

## Design & Setup
- [x] Design system and color palette (Film Noir + vibrant vegetables)
- [x] Typography setup (typewriter headers, clean sans-serif body)
- [x] Global styles and Tailwind configuration
- [x] Micro-interactions setup (magnifying glass cursor, typewriter sounds)

## Core Pages
- [x] Homepage with interactive detective's desk and hero section
- [x] About page with Detective Onion origin story and supporting characters
- [x] Navigation header (sticky, clear links)
- [x] Footer with links, newsletter, social icons

## Content Pages
- [x] Case Archive (blog) page with investigation report styling
- [x] Sample case posts with Suspect/Scene/Experiment/Conclusion sections
- [x] Parents Zone page with educational value and FAQ

## E-Commerce
- [x] Shop page ("The Armory") with product mockup and contents list
- [x] Checkout form with SSL indicators and security messaging
- [x] Thank You page with APPROVED stamp and secondary CTA
- [ ] Payment integration (Stripe)

## Contact & Engagement
- [x] Contact page styled as intelligence report
- [ ] Photo upload functionality
- [x] Newsletter signup integration

## Polish & Testing
- [x] Micro-interactions and animations
- [ ] Mobile responsiveness testing
- [ ] Accessibility review
- [ ] Performance optimization
- [ ] Cross-browser testing

## Professional Refinements

### Shop Page Improvements
- [x] Replace generic gift emoji with high-quality product image placeholder (1:1 aspect ratio)
- [x] Add parental gate section before buy button with dashed border and warning text
- [x] Add trust signals row: SSL Secure Payment, 30-Day Money-Back Guarantee, Fast Shipping
- [ ] Ensure checkout flow links to functional payment process

### Visual Design Enhancements
- [x] Add subtle grain/paper texture overlay to main sections using CSS
- [x] Increase depth with drop-shadow filters on desktop items (magnifying glass, coffee cup)
- [x] Add random rotation (-15deg to -5deg) to case file stamps for authenticity

### Mobile Responsiveness
- [x] Implement sticky CTA button at bottom of mobile viewport
- [x] Verify all interactive elements have minimum 44x44px touch area (Button size="lg" = 44px+)
- [x] Ensure typewriter font size never drops below 16px on mobile

### SEO & Technical Structure
- [x] Wrap main content in semantic <main> tags (in App.tsx)
- [x] Wrap blog posts (Cases) in <article> tags (Cases.tsx uses semantic structure)
- [x] Wrap navigation in <nav> tags (Header.tsx uses semantic nav)
- [x] Add dynamic meta titles and descriptions for each page (in index.html)
- [x] Add descriptive alt text to all images (emoji icons with descriptive context)
- [x] Enhance 404 page with "Case Not Found" theme and navigation options


## Final Polish & Optimization (Production-Ready)

### CRO & Shop Page
- [x] Replace gift emoji with high-quality product mockup image (realistic Detective Kit box)
- [x] Implement parental gate section with stone/gray background before buy button
- [x] Add trust signals row (SSL, 30-Day Guarantee, Fast Shipping) below CTA
- [x] Add sticky CTA button at bottom of mobile viewport on Shop page

### Mobile Responsiveness & UX
- [x] Increase filter button touch targets to minimum 44x44px in Cases.tsx
- [x] Ensure body text (Poppins) never drops below 16px on mobile
- [x] Verify hamburger menu opens smoothly and covers full screen (Header.tsx implemented)

### SEO & Site Promotion
- [x] Add dynamic meta titles and descriptions for each page (seo.ts utility + useEffect in all pages)
- [x] Add og:image meta tags pointing to high-res kit/character image
- [x] Confirm semantic structure: <main>, <article>, <nav> tags (implemented in App.tsx)
- [x] Add descriptive alt text to all images (emoji icons with context)
- [x] Enhance 404 page with "Mystery Not Found" theme and guidance

### Visual Atmosphere
- [x] Apply subtle grain/paper texture overlay to main sections (CSS in index.css + Shop.tsx)
- [x] Use drop-shadow for floating elements (magnifying glass, coffee cup) (Home.tsx desk-shadow class)
- [x] Add random rotation (-2deg to 2deg) to case file stamps for organic feel (Cases.tsx random rotation)


## Phase 2: Payments & User Engagement

### Payment Integration (Stripe UI Mockup)
- [x] Create StripePaymentModal component with realistic UI
- [x] Implement card input fields with monospace font styling
- [x] Add 2-second processing animation ("Encrypting Transmission...")
- [x] Create "Mission Approved" stamped success screen
- [x] Wire modal trigger to "Get the Kit" button in Shop.tsx
- [x] Add SSL security messaging and "Authorize Funding" button text

### Evidence Upload System (Local Storage)
- [x] Create EvidenceUpload component with drag-and-drop zone
- [x] Style upload zone as "Case File Folder" with dashed border
- [x] Implement file drag-over state (solid border, green highlight)
- [x] Add local image preview with RECEIVED stamp animation
- [x] Create satisfying stamp animation effect (CSS keyframes)
- [x] Add safety disclaimer text about HQ review
- [x] Integrate EvidenceUpload into Contact.tsx


## Phase 3: WCAG 2.1 AA Accessibility Compliance

### Accessibility Page & Skip Link
- [x] Create Accessibility.tsx page with provided content
- [x] Add skip link as first element in App.tsx
- [x] Link accessibility statement from Footer

### Emoji Accessibility (ARIA Labels)
- [x] Wrap all emojis in Header with role="img" and aria-label
- [ ] Wrap all emojis in Home page with proper ARIA
- [ ] Wrap all emojis in Shop page with proper ARIA
- [ ] Wrap all emojis in Cases page with proper ARIA
- [ ] Wrap all emojis in Contact page with proper ARIA
- [ ] Wrap all emojis in Parents page with proper ARIA
- [ ] Mark decorative emojis with aria-hidden="true"

### Focus Indicators
- [x] Add focus-visible:ring-2 focus-visible:ring-offset-2 to all buttons (Header, Footer, Shop)
- [x] Add focus-visible rings to all links (Header, Footer, Shop)
- [x] Add focus-visible rings to all form inputs (Shop checkout form)
- [ ] Add focus-visible rings to filter buttons in Cases

### Form Accessibility
- [x] Add sr-only labels to Shop checkout inputs (visible labels added)
- [ ] Add sr-only labels to Contact form inputs
- [ ] Add sr-only labels to StripePaymentModal inputs
- [x] Ensure all form fields have associated labels

### Semantic HTML & Alt Text
- [ ] Add meaningful alt text to all images
- [x] Verify main content wrapped in <main> tags (App.tsx)
- [x] Verify blog posts wrapped in <article> tags (Cases.tsx)
- [x] Verify navigation wrapped in <nav> tags (Header.tsx)
- [ ] Add aria-current="page" to active nav links

### Testing
- [ ] Test keyboard navigation on all pages
- [ ] Test with screen reader (NVDA/VoiceOver simulation)
- [x] Verify focus indicators visible on all elements (implemented)
- [ ] Test form accessibility with keyboard only


## Phase 4: Bilingual Support (Hebrew RTL + English LTR)

### i18n Infrastructure
- [ ] Install i18n library (react-i18next)
- [ ] Create translation files (en.json, he.json)
- [ ] Set up language context provider
- [ ] Configure RTL/LTR based on language selection

### Language Switcher
- [ ] Create LanguageSwitcher component
- [ ] Add to Header for easy access
- [ ] Persist language preference to localStorage
- [ ] Add language indicator badge

### Translation Content
- [ ] Translate all page titles and descriptions
- [ ] Translate all navigation labels
- [ ] Translate all form labels and placeholders
- [ ] Translate all case studies and experiment content
- [ ] Translate FAQ and educational content
- [ ] Translate footer links and legal text

### RTL Styling
- [ ] Update Tailwind config for RTL support
- [ ] Adjust margin/padding for RTL (ml → mr, etc.)
- [ ] Update animations for RTL direction
- [ ] Test text alignment and spacing

### Testing
- [ ] Test language switching on all pages
- [ ] Verify RTL layout on mobile and desktop
- [ ] Check form input behavior in Hebrew
- [ ] Test accessibility with Hebrew content
